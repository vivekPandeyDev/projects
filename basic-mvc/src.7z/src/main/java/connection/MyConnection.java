package connection;

public class MyConnection {
}
